EAR1 <-
structure(function (..., inst = NULL) 
{
    list( predictors = match.call(expand.dots = FALSE)[["..."]], 
        term = function(predLabels, ...) {
              paste( "log( exp(", predLabels[1], ")+(",
                      predLabels[2],
                      "))", sep="" )
        }, 
       call = as.expression(match.call()))
}, class = "nonlin")
