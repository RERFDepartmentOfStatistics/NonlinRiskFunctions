LogRR3 <-
structure(function (..., inst = NULL)
{
    list( predictors = match.call(expand.dots = FALSE)[["..."]], 
        term = function(predLabels, ...) {
              paste( "log(1+(", predLabels[1],
                      ")*exp(", predLabels[2],
                      ")*(1+",  predLabels[3], "))", sep="" )
        }, 
       call = as.expression(match.call()))
}, class = "nonlin")
