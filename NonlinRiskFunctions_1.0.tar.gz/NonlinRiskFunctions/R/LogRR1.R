LogRR1 <-
structure(function(expression, inst = NULL)
{
    list(predictors = list(substitute(expression)),
         term = function(predictors, ...) {
             paste("log(1+", predictors, ")", sep = "")
         },
         call = as.expression(match.call()))
}, class = "nonlin")
